package com.example.portfolio

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.content.Intent
import android.net.Uri
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Toast text
        val profileclick = findViewById<ImageView>(R.id.imageView3)
        profileclick.setOnClickListener {
            Toast.makeText(this,"Hey this is Devloper's Profile (KESHAV RAJ)",Toast.LENGTH_SHORT).show()

        }
        // All type of Buttons are here
        val openInstaButton = findViewById<Button>(R.id.instagram)
        openInstaButton.setOnClickListener {
            val url = "https://www.instagram.com/proxy_chain/"
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            startActivity(intent)

        }

        val openWhatsappButton = findViewById<Button>(R.id.whatsapp)
        openWhatsappButton.setOnClickListener{
            val url = "https://wa.me/+917292870631/"
            val intent = Intent(Intent.ACTION_VIEW,Uri.parse(url))
            startActivity(intent)

        }
        val openDilarText = findViewById<TextView>(R.id.textView4)
        openDilarText.setOnClickListener {
            val url = "tel:+917292870631/"
            val intent = Intent(Intent.ACTION_VIEW,Uri.parse(url))
            startActivity(intent)

        }
        val openMailText = findViewById<TextView>(R.id.textView3)
        openMailText.setOnClickListener {
            val url = "mailto:keshavrajbingo@gmail.com"
            val intent = Intent(Intent.ACTION_VIEW,Uri.parse(url))
            startActivity(intent)

        }
        val openMapText = findViewById<TextView>(R.id.textView5)
        openMapText.setOnClickListener {
            val url = "https://maps.app.goo.gl/Q8JwtGLjAs2LCPoC7"
            val intent = Intent(Intent.ACTION_VIEW,Uri.parse(url))
            startActivity(intent)

        }
        val openGithubButton = findViewById<Button>(R.id.github)
        openGithubButton.setOnClickListener {
            val url = "https://github.com/blackshark1213"
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            startActivity(intent)

        }
        val opensecondButton = findViewById<ImageButton>(R.id.imagesecond)
        opensecondButton.setOnClickListener {
            val intent = Intent(this,MainActivity2::class.java)
            startActivity(intent)
            finish()
        }
        //-----------------
        // pop up buttons
        val openskillButton = findViewById<TextView>(R.id.skilltext)
        openskillButton.setOnClickListener{
            val intent = Intent(this,Skill::class.java)
            startActivity(intent)
            finish()
        }

        val openeducationButton = findViewById<TextView>(R.id.educationtext)
        openeducationButton.setOnClickListener{
            val intent = Intent(this,Education::class.java)
            startActivity(intent)
            finish()
        }

        val openaboutButton = findViewById<TextView>(R.id.abouttext)
        openaboutButton.setOnClickListener {
            val intent = Intent(this,About::class.java)
            startActivity(intent)
            finish()        }


    }
}