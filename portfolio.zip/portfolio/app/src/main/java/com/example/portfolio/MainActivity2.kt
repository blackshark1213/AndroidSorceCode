package com.example.portfolio

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity2 : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main2)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        //        ---  buttond for home and project jump
        val openhomeButton = findViewById<ImageButton>(R.id.imageHome)
        openhomeButton.setOnClickListener {
            val intent = Intent(this,MainActivity::class.java)
            startActivity(intent)
            finish()
        }
        val c_certificate = findViewById<ImageView>(R.id.c_certificates)
        c_certificate.setOnClickListener {
            Toast.makeText(this,"This is my C certificates from sololearn", Toast.LENGTH_SHORT).show()
        }
        val cpp_certificate = findViewById<ImageView>(R.id.cpp_certificates)
        cpp_certificate.setOnClickListener {
            Toast.makeText(this,"This is my C++ certificates from sololearn", Toast.LENGTH_SHORT).show()
        }
        val java_certificate = findViewById<ImageView>(R.id.java_certificates)
        java_certificate.setOnClickListener {
            Toast.makeText(this,"This is my Java certificates from sololearn", Toast.LENGTH_SHORT).show()
        }
        val sql_certificate = findViewById<ImageView>(R.id.sql_certificates)
        sql_certificate.setOnClickListener {
            Toast.makeText(this,"This is my SQL certificates from sololearn", Toast.LENGTH_SHORT).show()
        }
        var sourcecode = findViewById<TextView>(R.id.sourcecode)
        sourcecode.setOnClickListener {
            var i = Intent(Intent.ACTION_VIEW,Uri.parse("https://"))
            startActivity(i)
        }

    }
}

