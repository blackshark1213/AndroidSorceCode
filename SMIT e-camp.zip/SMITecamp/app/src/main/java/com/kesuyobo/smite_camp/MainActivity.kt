package com.kesuyobo.smite_camp

import android.Manifest
import android.app.AlertDialog
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.webkit.DownloadListener
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceError
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.PermissionChecker
import java.io.File

class MainActivity : ComponentActivity() {

    lateinit var webView: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // In MainActivity onCreate method
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PermissionChecker.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), 1)
        }

        // Request permission for writing to storage
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE), 1)
        }

        setContent {
            WebViewScreen("https://ecm.smtech.in/ecm/Students/index.aspx")
            Toast.makeText(applicationContext, "Apk Dev Keshav Raj", Toast.LENGTH_SHORT).show()
            Toast.makeText(applicationContext, "Welcome to E-cam SMIT", Toast.LENGTH_LONG).show()

        }
    }

    // Handle back button
    override fun onBackPressed() {
        //super.onBackPressed()
        if (this::webView.isInitialized && webView.canGoBack()) {
            // If WebView has history, go back to the previous page
            webView.goBack()
        } else {
            // If there's no history, proceed with the default back button behavior
           // super.onBackPressed()
            // Show confirmation dialog before exiting
            showExitConfirmationDialog()
        }
    }
    private fun showExitConfirmationDialog() {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Exit Confirmation")
        builder.setMessage("Are you sure you want to exit the app?")

        // Customizing the Positive button
        builder.setPositiveButton("Yes") { dialog, which ->
            super.onBackPressed() // Call the default back press behavior
            Toast.makeText(applicationContext, "App Exited", Toast.LENGTH_SHORT).show()
        }

        // Customizing the Negative button
        builder.setNegativeButton("No") { dialog, which ->
            dialog.dismiss()  // Dismiss the dialog and stay in the app
            Toast.makeText(applicationContext, "Welcome again", Toast.LENGTH_SHORT).show()
        }

//        // Optional: Adding a neutral button for another action (example)
//        builder.setNeutralButton("Url") { dialog, which ->
//
//        }

        // Show the dialog
        builder.show()
    }

}

@Composable
fun WebViewScreen(url: String) {
    AndroidView(
        factory = { context ->
            WebView(context).apply {
                // Store reference to WebView for back button handling
                (context as MainActivity).webView = this

                // Enable JavaScript
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true

                // Set up WebViewClient to handle URL redirects
                webViewClient = MyWebViewClient()

                // Handle file downloads by setting a DownloadListener
                setDownloadListener { url, userAgent, contentDisposition, mimeType, contentLength ->
                    // Call function to handle download
                    downloadFile(context, url)
                }

                // Load the initial URL
                loadUrl(url)
            }
        },
        modifier = Modifier.fillMaxSize()
    )
}

class MyWebViewClient : WebViewClient() {
    override fun shouldOverrideUrlLoading(view: WebView?, url: String): Boolean {
        // Open the URL inside the WebView
        view?.loadUrl(url)
        return true
    }

    override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
        super.onReceivedError(view, request, error)
        // Handle errors
        view?.loadData("<html><body><h2>Page Not Available</h2></body></html>", "text/html", "UTF-8")
    }
}


// Function to handle downloading the file using Android's DownloadManager
fun downloadFile(context: Context, url: String) {
    val downloadManager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
    val uri = Uri.parse(url)

    // Request to download the file
    val request = DownloadManager.Request(uri)
    request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)

    // Check for Android 10+ (Scoped Storage)
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
        // Use the Downloads directory for Android 10+ devices
        request.setDestinationInExternalFilesDir(context, null, uri.lastPathSegment)
    } else {
        // For older devices, use the public Downloads directory
        request.setDestinationInExternalPublicDir(android.os.Environment.DIRECTORY_DOWNLOADS, uri.lastPathSegment)
    }

    // Enqueue the download request
    downloadManager.enqueue(request)

    // Notify the user that the download has started
    Toast.makeText(context, "Downloading file...", Toast.LENGTH_SHORT).show()
}
